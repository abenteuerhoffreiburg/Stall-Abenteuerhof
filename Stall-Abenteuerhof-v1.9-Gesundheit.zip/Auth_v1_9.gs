const PONY_TEAM_USERS_PROPERTY_ = 'PONY_TEAM_USERS';
const PONY_TEAM_ADMINS_PROPERTY_ = 'PONY_TEAM_ADMINS';
const PONY_AUTH_SECRET_PROPERTY_ = 'PONY_AUTH_SECRET';
const PONY_TEAM_TOKEN_TTL_MS_ = 30 * 24 * 60 * 60 * 1000; // 30 Tage

function serverTeamUsers_() {
  const raw = PropertiesService.getScriptProperties().getProperty(PONY_TEAM_USERS_PROPERTY_);
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch (e) {
    throw new Error('PONY_TEAM_USERS ist kein gültiges JSON-Objekt.');
  }
}

function serverSaveTeamUsers_(users) {
  PropertiesService.getScriptProperties().setProperty(PONY_TEAM_USERS_PROPERTY_, JSON.stringify(users || {}));
}

function serverTeamAdmins_() {
  const raw = PropertiesService.getScriptProperties().getProperty(PONY_TEAM_ADMINS_PROPERTY_);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch (e) {
    throw new Error('PONY_TEAM_ADMINS ist kein gültiges JSON-Array.');
  }
}

function serverSaveTeamAdmins_(admins) {
  const unique = [];
  (admins || []).forEach(function(name) {
    const clean = String(name || '').trim();
    if (clean && unique.indexOf(clean) === -1) unique.push(clean);
  });
  PropertiesService.getScriptProperties().setProperty(PONY_TEAM_ADMINS_PROPERTY_, JSON.stringify(unique));
}

function serverCanonicalTeamUser_(name, users) {
  const wanted = String(name || '').trim().toLowerCase();
  if (!wanted) return '';
  const names = Object.keys(users || {});
  for (let i = 0; i < names.length; i++) {
    if (String(names[i]).trim().toLowerCase() === wanted) return names[i];
  }
  return '';
}

function serverIsAdminName_(name, users, admins) {
  const canonical = serverCanonicalTeamUser_(name, users || serverTeamUsers_());
  if (!canonical) return false;
  const list = admins || serverTeamAdmins_();
  return list.some(function(adminName) {
    return String(adminName).trim().toLowerCase() === canonical.toLowerCase();
  });
}


function serverAuthSecret_() {
  const props = PropertiesService.getScriptProperties();
  let secret = props.getProperty(PONY_AUTH_SECRET_PROPERTY_);
  if (!secret) {
    secret = Utilities.getUuid() + Utilities.getUuid() + Utilities.getUuid();
    props.setProperty(PONY_AUTH_SECRET_PROPERTY_, secret);
  }
  return secret;
}

function serverB64_(value) {
  return Utilities.base64EncodeWebSafe(String(value), Utilities.Charset.UTF_8).replace(/=+$/g, '');
}

function serverB64Decode_(value) {
  const bytes = Utilities.base64DecodeWebSafe(String(value));
  return Utilities.newBlob(bytes).getDataAsString('UTF-8');
}

function serverHmac_(value, secret) {
  const bytes = Utilities.computeHmacSha256Signature(String(value), String(secret), Utilities.Charset.UTF_8);
  return Utilities.base64EncodeWebSafe(bytes).replace(/=+$/g, '');
}

function serverUserVersion_(name, pin, isAdmin, secret) {
  // PIN steht nie im Token. Änderungen an PIN oder Admin-Recht machen alte Tokens ungültig.
  return serverHmac_(String(name) + '\n' + String(pin) + '\n' + (isAdmin ? 'admin' : 'team'), secret).slice(0, 24);
}

function serverValidatePin_(pin) {
  return String(pin || '').trim().length >= 6;
}

/** Persönlicher Login. */
function serverAuthenticateTeam(name, pin) {
  const users = serverTeamUsers_();
  if (!Object.keys(users).length) return { ok: false, error: 'not_configured' };

  const canonical = serverCanonicalTeamUser_(name, users);
  const suppliedPin = String(pin || '').trim();
  if (!canonical || !suppliedPin || suppliedPin !== String(users[canonical]).trim()) {
    return { ok: false, error: 'invalid_login' };
  }

  const admins = serverTeamAdmins_();
  const isAdmin = serverIsAdminName_(canonical, users, admins);
  const secret = serverAuthSecret_();
  const payload = {
    u: canonical,
    exp: Date.now() + PONY_TEAM_TOKEN_TTL_MS_,
    v: serverUserVersion_(canonical, users[canonical], isAdmin, secret),
    n: Utilities.getUuid()
  };
  const body = serverB64_(JSON.stringify(payload));
  const sig = serverHmac_(body, secret);

  return {
    ok: true,
    token: body + '.' + sig,
    expiresAt: payload.exp,
    user: canonical,
    admin: isAdmin
  };
}

/** Liefert Sitzung oder null. Prüft bei JEDEM Aufruf aktuelle Benutzer-/Admin-Daten. */
function serverTeamSessionFromToken_(token) {
  try {
    const parts = String(token || '').split('.');
    if (parts.length !== 2) return null;
    const secret = serverAuthSecret_();
    if (serverHmac_(parts[0], secret) !== parts[1]) return null;

    const payload = JSON.parse(serverB64Decode_(parts[0]));
    if (!payload || !payload.u || !payload.exp || Date.now() >= Number(payload.exp)) return null;

    const users = serverTeamUsers_();
    const canonical = serverCanonicalTeamUser_(payload.u, users);
    if (!canonical) return null; // Zugang wurde entfernt

    const admins = serverTeamAdmins_();
    const isAdmin = serverIsAdminName_(canonical, users, admins);
    const expectedVersion = serverUserVersion_(canonical, users[canonical], isAdmin, secret);
    if (payload.v !== expectedVersion) return null; // PIN oder Admin-Recht wurde geändert

    return { user: canonical, admin: isAdmin, exp: Number(payload.exp) };
  } catch (e) {
    return null;
  }
}

function serverTeamUserFromToken_(token) {
  const session = serverTeamSessionFromToken_(token);
  return session ? session.user : '';
}

function serverIsValidTeamToken_(token) {
  return !!serverTeamSessionFromToken_(token);
}

function serverIsAdminToken_(token) {
  const session = serverTeamSessionFromToken_(token);
  return !!(session && session.admin);
}

/** Frontend prüft damit beim Start, ob ein gespeicherter Zugang noch gültig ist. */
function serverDescribeTeamSession(teamToken) {
  const session = serverTeamSessionFromToken_(teamToken);
  if (!session) return { ok: true, valid: false };
  return { ok: true, valid: true, user: session.user, admin: !!session.admin, expiresAt: session.exp };
}

function serverRequireAdmin_(teamToken) {
  const session = serverTeamSessionFromToken_(teamToken);
  if (!session || !session.admin) throw new Error('Nicht autorisiert: Admin-Zugang erforderlich.');
  return session;
}

function serverAdminListTeamUsers(teamToken) {
  const session = serverRequireAdmin_(teamToken);
  const users = serverTeamUsers_();
  const admins = serverTeamAdmins_();
  const list = Object.keys(users).sort(function(a,b) { return a.localeCompare(b, 'de'); }).map(function(name) {
    return { name: name, admin: serverIsAdminName_(name, users, admins) };
  });
  return { ok: true, users: list, currentUser: session.user };
}

function serverAdminAddTeamUser(teamToken, name, pin, makeAdmin) {
  serverRequireAdmin_(teamToken);
  const cleanName = String(name || '').trim();
  const cleanPin = String(pin || '').trim();
  if (!cleanName) return { ok:false, error:'invalid_name', message:'Bitte einen Namen eingeben.' };
  if (!serverValidatePin_(cleanPin)) return { ok:false, error:'weak_pin', message:'Die PIN muss mindestens 6 Zeichen lang sein.' };

  const users = serverTeamUsers_();
  if (serverCanonicalTeamUser_(cleanName, users)) return { ok:false, error:'exists', message:'Für diese Person gibt es bereits einen Pferdeteam-Zugang.' };
  users[cleanName] = cleanPin;
  serverSaveTeamUsers_(users);

  if (makeAdmin) {
    const admins = serverTeamAdmins_();
    admins.push(cleanName);
    serverSaveTeamAdmins_(admins);
  }
  return { ok:true };
}

function serverAdminUpdateTeamUser(teamToken, name, newPin, makeAdmin) {
  const session = serverRequireAdmin_(teamToken);
  const users = serverTeamUsers_();
  const canonical = serverCanonicalTeamUser_(name, users);
  if (!canonical) return { ok:false, error:'not_found', message:'Dieser Zugang existiert nicht mehr.' };

  const suppliedPin = String(newPin || '').trim();
  if (suppliedPin && !serverValidatePin_(suppliedPin)) {
    return { ok:false, error:'weak_pin', message:'Die PIN muss mindestens 6 Zeichen lang sein.' };
  }

  let admins = serverTeamAdmins_();
  const currentlyAdmin = serverIsAdminName_(canonical, users, admins);
  const wantsAdmin = !!makeAdmin;

  // Erst alle Rechteänderungen prüfen. So wird bei einem abgelehnten Vorgang
  // nicht versehentlich trotzdem schon die PIN geändert.
  if (currentlyAdmin !== wantsAdmin) {
    if (canonical.toLowerCase() === session.user.toLowerCase() && !wantsAdmin) {
      return { ok:false, error:'self_admin_change', message:'Deine eigenen Admin-Rechte kannst du hier nicht entziehen. Das muss eine andere Admin-Person übernehmen.' };
    }
    if (!wantsAdmin) {
      const prospectiveAdmins = admins.filter(function(n) {
        return String(n).trim().toLowerCase() !== canonical.toLowerCase();
      });
      const activeAdmins = prospectiveAdmins.filter(function(n) { return !!serverCanonicalTeamUser_(n, users); });
      if (!activeAdmins.length) return { ok:false, error:'last_admin', message:'Mindestens eine Admin-Person muss erhalten bleiben.' };
    }
  }

  if (suppliedPin) users[canonical] = suppliedPin;
  serverSaveTeamUsers_(users);

  if (currentlyAdmin !== wantsAdmin) {
    if (wantsAdmin) admins.push(canonical);
    else admins = admins.filter(function(n) { return String(n).trim().toLowerCase() !== canonical.toLowerCase(); });
    serverSaveTeamAdmins_(admins);
  }

  return { ok:true };
}

function serverAdminRemoveTeamUser(teamToken, name) {
  const session = serverRequireAdmin_(teamToken);
  const users = serverTeamUsers_();
  const canonical = serverCanonicalTeamUser_(name, users);
  if (!canonical) return { ok:false, error:'not_found', message:'Dieser Zugang existiert nicht mehr.' };
  if (canonical.toLowerCase() === session.user.toLowerCase()) {
    return { ok:false, error:'self_remove', message:'Deinen eigenen Zugang kannst du hier nicht entfernen. Das muss eine andere Admin-Person übernehmen.' };
  }

  const admins = serverTeamAdmins_();
  const wasAdmin = serverIsAdminName_(canonical, users, admins);
  if (wasAdmin) {
    const remainingAdmins = admins.filter(function(n) {
      return String(n).trim().toLowerCase() !== canonical.toLowerCase() && !!serverCanonicalTeamUser_(n, users);
    });
    if (!remainingAdmins.length) return { ok:false, error:'last_admin', message:'Mindestens eine Admin-Person muss erhalten bleiben.' };
  }

  delete users[canonical];
  serverSaveTeamUsers_(users);
  serverSaveTeamAdmins_(admins.filter(function(n) { return String(n).trim().toLowerCase() !== canonical.toLowerCase(); }));
  return { ok:true };
}

/** Schlüssel, die nur das Pferdeteam SCHREIBEN/LÖSCHEN darf. */
function serverKeyNeedsTeamAuth_(key) {
  key = String(key || '');
  if (key === 'ponies') return true;
  if (key === 'pastures:status') return true;
  if (key === 'settings:todo-assignees') return true;
  if (key === 'settings:theme-colors') return true; // App-Farben nur durch Pferdeteam änderbar
  if (key === 'settings:schicht-days') return true; // Ferienstalldienst-Tage nur durch Pferdeteam änderbar
  if (key === 'settings:last-backup') return true; // Backup-Zeitpunkt intern
  if (key === 'settings:data-retention-policy') return true; // interne Aufbewahrungsregel
  if (key === 'customFerienWeeks') return true;
  if (key.indexOf('ponyinfo:') === 0) return true;
  if (key.indexOf('ponyinfo-history:') === 0) return true;
  if (key.indexOf('todo:') === 0) return true;
  if (key.indexOf('responsibility:') === 0) return true;
  if (key.indexOf('important-contact:') === 0) return true;
  if (key.indexOf('photo:') === 0) return true; // Pony-Profilfoto
  if (key.indexOf('healthack:') === 0) return true; // persönliche Lesebestätigungen Gesundheit
  if (key.indexOf('ponygroup:') === 0) return true; // Ponygruppen-Inhalte + Terminänderungen
  return false;
}


/**
 * Aktive Pferdeteam-Namen für Lesebestätigungen.
 * Darf jedes gültig eingeloggte Pferdeteam-Konto lesen, aber keine PINs.
 */
function serverListTeamUserNames(teamToken) {
  var session = serverTeamSessionFromToken_(teamToken);
  if (!session) {
    return { ok:false, error:'unauthorized', message:'Pferdeteam-Zugang bitte neu anmelden.' };
  }

  var users = serverTeamUsers_();
  var names = Object.keys(users || {}).filter(function(name) {
    return String(name || '').trim() !== '';
  });

  names.sort(function(a, b) {
    return String(a).localeCompare(String(b), 'de', { sensitivity:'base' });
  });

  return {
    ok: true,
    users: names,
    currentUser: session.user
  };
}




function serverRequireTeamForKey_(key, teamToken) {
  if (!serverKeyNeedsTeamAuth_(key)) return;
  if (serverIsValidTeamToken_(teamToken)) return;
  throw new Error('Nicht autorisiert: persönlicher Pferdeteam-Login erforderlich.');
}

function serverRequireTeam_(teamToken) {
  if (!serverIsValidTeamToken_(teamToken)) {
    throw new Error('Nicht autorisiert: persönlicher Pferdeteam-Login erforderlich.');
  }
}

/**
 * Leseschutz: To-dos sind ein interner Pferdeteam-Bereich und werden ohne
 * gültiges Team-Token gar nicht erst an den Browser ausgeliefert.
 */
function serverFilterAllDataForViewer_(dataObj, teamToken) {
  const out = {};
  const isTeam = serverIsValidTeamToken_(teamToken);

  Object.keys(dataObj || {}).forEach(function(key) {
    if (!isTeam && (
      key.indexOf('todo:') === 0 ||
      key === 'settings:todo-assignees' ||
      key.indexOf('healthack:') === 0 ||
      key.indexOf('ponygroup:') === 0
    )) return;

    out[key] = dataObj[key];
  });

  return out;
}
function testFranziLogin() {
  const users = serverTeamUsers_();

  Logger.log("Gefundene Nutzer: " + JSON.stringify(Object.keys(users)));
  Logger.log("Franzi vorhanden: " + Boolean(users["Franzi"]));

  const result = serverAuthenticateTeam(
    "Franzi",
    users["Franzi"]
  );

  Logger.log(JSON.stringify(result));
}