function doGet(e) {
  var action = e && e.parameter ? e.parameter.action : '';

  if (!action) {
    return HtmlService.createHtmlOutputFromFile('index').setTitle('Pony-Tracker');
  }

  var sheet = getSheet();
  var data = sheet.getDataRange().getValues();

  if (action === 'all') {
    var obj = {};
    for (var i = 1; i < data.length; i++) {
      if (data[i][0]) obj[data[i][0]] = data[i][1];
    }
    return jsonOut({ data: obj });
  }

  if (action === 'get') {
    var key = e.parameter.key;
    for (var j = 1; j < data.length; j++) {
      if (String(data[j][0]) === String(key)) {
        return jsonOut({ value: data[j][1] });
      }
    }
    return jsonOut({ value: null });
  }

  if (action === 'list') {
    var prefix = e.parameter.prefix || '';
    var keys = [];

    for (var k = 1; k < data.length; k++) {
      if (data[k][0] && String(data[k][0]).indexOf(prefix) === 0) {
        keys.push(data[k][0]);
      }
    }

    return jsonOut({ keys: keys });
  }

  return jsonOut({ error: 'unknown_action' });
}

function doPost(e) {
  var data = {};

  try {
    data = JSON.parse(
      e && e.postData && e.postData.contents
        ? e.postData.contents
        : '{}'
    );
  } catch (err) {
    return jsonOut({ ok: false, error: 'invalid_json' });
  }

  // ---- Push-Aktionen zuerst abfangen ----
  var pushRoute = serverHandlePushAction_(data);
  if (pushRoute && pushRoute.handled) {
    return jsonOut(pushRoute.result);
  }

  var action = String(data.action || '');

  // ---- Login ----
  if (action === 'authenticateTeam') {
    return jsonOut(
      serverAuthenticateTeam(data.name, data.pin)
    );
  }

  if (action === 'describeTeamSession') {
    return jsonOut(
      serverDescribeTeamSession(data.teamToken || '')
    );
  }

  // ---- Pferdeteam-Namen (ohne PINs) für Lesebestätigungen ----
  if (action === 'listTeamUserNames') {
    return jsonOut(
      serverListTeamUserNames(data.teamToken || '')
    );
  }

  // ---- Admin / Zugänge verwalten ----
  if (action === 'listTeamUsers') {
    return jsonOut(
      serverAdminListTeamUsers(data.teamToken || '')
    );
  }

  if (action === 'addTeamUser') {
    return jsonOut(
      serverAdminAddTeamUser(
        data.teamToken || '',
        data.name,
        data.pin,
        data.admin
      )
    );
  }

  if (action === 'updateTeamUser') {
    return jsonOut(
      serverAdminUpdateTeamUser(
        data.teamToken || '',
        data.name,
        data.pin || '',
        data.admin
      )
    );
  }

  if (action === 'removeTeamUser') {
    return jsonOut(
      serverAdminRemoveTeamUser(
        data.teamToken || '',
        data.name
      )
    );
  }

  // ---- Alle Tracker-Daten laden ----
  if (action === 'all') {
    var sheet = getSheet();
    var rows = sheet.getDataRange().getValues();
    var obj = {};

    for (var i = 1; i < rows.length; i++) {
      if (rows[i][0]) {
        obj[rows[i][0]] = rows[i][1];
      }
    }

    obj = serverFilterAllDataForViewer_(
      obj,
      data.teamToken || ''
    );

    return jsonOut({ data: obj });
  }

  // ---- Daten speichern ----
  if (action === 'set') {
    serverRequireTeamForKey_(
      data.key,
      data.teamToken || ''
    );

    return jsonOut(
      serverSet(data.key, data.value)
    );
  }

  // ---- Daten löschen ----
  if (action === 'delete') {
    serverRequireTeamForKey_(
      data.key,
      data.teamToken || ''
    );

    return jsonOut(
      serverDelete(data.key)
    );
  }

  // ---- Fotos / Audio ----
  if (action === 'uploadPhoto') {
    return jsonOut(
      serverUploadPhoto(
        data.base64,
        data.mimeType,
        data.filename
      )
    );
  }

  if (action === 'deletePhoto') {
    return jsonOut(
      serverDeletePhoto(data.fileId)
    );
  }

  return jsonOut({
    ok: false,
    error: 'unknown_action'
  });
}

function getPhotoFolder() {
  var folderName = 'PonyTrackerFotos';
  var folders = DriveApp.getFoldersByName(folderName);

  if (folders.hasNext()) {
    return folders.next();
  }

  return DriveApp.createFolder(folderName);
}

function getSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('data');

  if (!sheet) {
    sheet = ss.insertSheet('data');
    sheet.appendRow(['key', 'value']);
  }

  return sheet;
}

function jsonOut(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// -----------------------------------------------------------------------------
// Direkte Server-Funktionen für google.script.run
// -----------------------------------------------------------------------------

function serverGetAll(teamToken) {
  var sheet = getSheet();
  var rows = sheet.getDataRange().getValues();
  var obj = {};

  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0]) {
      obj[rows[i][0]] = rows[i][1];
    }
  }

  return serverFilterAllDataForViewer_(obj, teamToken || '');
}

function serverSet(key, value) {
  var sheet = getSheet();
  var data = sheet.getDataRange().getValues();

  for (var i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(key)) {
      sheet.getRange(i + 1, 2).setValue(value);
      return { ok: true };
    }
  }

  sheet.appendRow([key, value]);
  return { ok: true };
}

function serverDelete(key) {
  var sheet = getSheet();
  var data = sheet.getDataRange().getValues();

  for (var i = data.length - 1; i >= 1; i--) {
    if (String(data[i][0]) === String(key)) {
      sheet.deleteRow(i + 1);
      return { ok: true };
    }
  }

  return { ok: true };
}

function serverUploadPhoto(base64, mimeType, filename) {
  if (!base64) {
    return {
      ok: false,
      error: 'missing_base64'
    };
  }

  try {
    var folder = getPhotoFolder();
    var bytes = Utilities.base64Decode(base64);
    var safeMimeType = mimeType || 'image/jpeg';
    var safeFilename = filename || 'foto.jpg';

    var blob = Utilities.newBlob(
      bytes,
      safeMimeType,
      safeFilename
    );

    var file = folder.createFile(blob);

    file.setSharing(
      DriveApp.Access.ANYONE_WITH_LINK,
      DriveApp.Permission.VIEW
    );

    return {
      ok: true,
      fileId: file.getId()
    };
  } catch (err) {
    return {
      ok: false,
      error: 'upload_failed',
      message: String(err && err.message ? err.message : err)
    };
  }
}

function serverDeletePhoto(fileId) {
  if (!fileId) {
    return { ok: true };
  }

  try {
    var file = DriveApp.getFileById(fileId);
    file.setTrashed(true);
  } catch (err) {
    // Schon gelöscht oder ungültige ID – für die App kein Problem.
  }

  return { ok: true };
}

// -----------------------------------------------------------------------------
// Tests
// -----------------------------------------------------------------------------

function testDoPostLogin() {
  var users = serverTeamUsers_();

  var e = {
    postData: {
      contents: JSON.stringify({
        action: 'authenticateTeam',
        name: 'Franzi',
        pin: users['Franzi']
      })
    }
  };

  var result = doPost(e);
  Logger.log(result.getContent());
}

function testSyncWrite() {
  var users = serverTeamUsers_();
  var auth = serverAuthenticateTeam('Franzi', users['Franzi']);

  var key = 'sync:test';
  var value = 'Test ' + new Date().toISOString();

  var e = {
    postData: {
      contents: JSON.stringify({
        action: 'set',
        key: key,
        value: value,
        teamToken: auth.token
      })
    }
  };

  var response = doPost(e);
  Logger.log('Antwort: ' + response.getContent());

  var rows = getSheet().getDataRange().getValues();
  var row = rows.find(function(r) {
    return String(r[0]) === key;
  });

  Logger.log(
    'Im Sheet: ' + (row ? row[1] : 'NICHT GEFUNDEN')
  );
}

function testPushConfig() {
  console.log(serverPushConfig());
}

function testPublishedPushConfig() {
  var url = 'https://script.google.com/macros/s/AKfycbydAWWFqswzO9dtC_fjkDvguZ3w77UBwq260J3yptsQjrrsLBESZdGNUF9q__EOeXeONw/exec';

  var response = UrlFetchApp.fetch(url, {
    method: 'post',
    contentType: 'text/plain',
    payload: JSON.stringify({
      action: 'pushConfig'
    }),
    muteHttpExceptions: true,
    followRedirects: true
  });

  console.log(response.getResponseCode());
  console.log(response.getContentText());
}
