STALL ABENTEUERHOF · v1.9 · Gesundheit

Neu:
- Gesundheit: Art des Eintrags auswählbar:
  Beobachtung / Tierarzt / Hufpflege / Osteopathie / Behandlung / Sonstiges.
- Bei Tierarzt, Hufpflege und Osteopathie kann die Fachperson/Praxis angegeben werden
  (z. B. Nadine).
- Der eigentliche Befund / was gemacht wurde bleibt als ausführliche Notiz dokumentiert.
- Ehrenamt-Gesundheitseinträge können jetzt Push auslösen.
  Diese Pushs gehen ausschließlich an gültige Pferdeteam-Accounts mit aktiviertem
  Gesundheits-Push und enthalten keine Gesundheitsdetails.
- Pferdeteam-Einträge verhalten sich beim Push wie bisher.
- Missverständliche Formulierung „Team-Einträge sind intern …“ wurde entfernt.
- Alte Gesundheitseinträge bleiben vollständig kompatibel.

Deployment:
GITHUB:
- index.html ersetzen
- sw.js ersetzen
- version.json ersetzen
- manifest.webmanifest kann ebenfalls aus diesem Paket genommen werden
- OneSignal-Worker bleibt gleich

APPS SCRIPT:
- Nur Push_OneSignal_v1_9_gesundheit.gs ist gegenüber v1.8 technisch geändert.
- Code.gs und Auth.gs sind identisch zu v1.8 und liegen nur der Vollständigkeit halber bei.
- Push-Datei ersetzen, speichern und neue Web-App-Version bereitstellen.

Test:
1. Als Ehrenamt ein Gesundheitsupdate anlegen.
2. „Benachrichtigung senden“ aktiviert lassen.
3. Pferdeteam-Handy mit aktiviertem Gesundheitspush sollte
   „Neue Gesundheitsbeobachtung“ erhalten.
4. Tierarzt/Hufpflege/Osteopathie auswählen und prüfen, ob Fachperson + Info
   im Gesundheitsverlauf erscheinen.
