/**
 * Stall Abenteuerhof – echte Web-Push-Benachrichtigungen über OneSignal.
 *
 * Script Properties (Apps Script > Projekteinstellungen > Skripteigenschaften):
 *   ONESIGNAL_APP_ID       = OneSignal App ID
 *   ONESIGNAL_APP_API_KEY  = OneSignal App API Key
 * Optional:
 *   STALL_APP_URL          = https://abenteuerhoffreiburg.github.io/Stall-Abenteuerhof/
 *   STALL_TIMEZONE         = Europe/Berlin
 *
 * Abhängigkeiten aus dem bestehenden Projekt:
 *   getSheet()
 *   serverTeamSessionFromToken_()
 *   serverRequireAdmin_()
 *   serverTeamUsers_(), serverTeamAdmins_(), serverIsAdminName_(),
 *   serverUserVersion_(), serverAuthSecret_()
 */

const STALL_PUSH_SUBS_SHEET_ = '_PushSubscriptions';
const STALL_PUSH_SENT_SHEET_ = '_PushSent';
const STALL_PUSH_DEFAULT_URL_ = 'https://abenteuerhoffreiburg.github.io/Stall-Abenteuerhof/';
const STALL_PUSH_DEFAULT_TZ_ = 'Europe/Berlin';
const STALL_PUSH_TRIGGER_FN_ = 'pushScheduledChecks';

const STALL_PUSH_GROUPS_ = [
  { id: 'mo-ponybande', weekday: 1, day: 'Montag', title: 'Ponybande', start: '14:30' },
  { id: 'di-1', weekday: 2, day: 'Dienstag', title: 'Gruppe 1', start: '14:30' },
  { id: 'di-2', weekday: 2, day: 'Dienstag', title: 'Gruppe 2', start: '16:00' },
  { id: 'mi-1', weekday: 3, day: 'Mittwoch', title: 'Gruppe 1', start: '14:30' },
  { id: 'mi-2', weekday: 3, day: 'Mittwoch', title: 'Gruppe 2', start: '16:00' },
  { id: 'do-1', weekday: 4, day: 'Donnerstag', title: 'Gruppe 1', start: '14:30' },
  { id: 'do-2', weekday: 4, day: 'Donnerstag', title: 'Gruppe 2', start: '16:00' }
];

function serverPushConfig() {
  const props = PropertiesService.getScriptProperties();
  const appId = String(props.getProperty('ONESIGNAL_APP_ID') || '').trim();
  const apiKey = String(props.getProperty('ONESIGNAL_APP_API_KEY') || '').trim();
  return {
    ok: true,
    enabled: !!(appId && apiKey),
    appId: appId || '',
    appUrl: pushAppUrl_()
  };
}

/**
 * Registriert genau dieses Browser-/PWA-Gerät. Team-Rechte werden serverseitig
 * mit dem persönlichen Team-Token geprüft und mit einer Versionssignatur gebunden.
 */
function serverSavePushPreferences(name, role, prefs, subscriptionId, teamToken, active) {
  const cleanSub = String(subscriptionId || '').trim();
  const cleanRequestedName = String(name || '').trim();
  let cleanRole = String(role || '').trim() === 'pferdeteam' ? 'pferdeteam' : 'ehrenamt';
  let cleanName = cleanRequestedName;
  let verifiedTeam = false;
  let teamVersion = '';

  if (cleanRole === 'pferdeteam') {
    const session = serverTeamSessionFromToken_(teamToken);
    if (!session) {
      return { ok: false, error: 'unauthorized', message: 'Pferdeteam-Zugang ist nicht mehr gültig.' };
    }
    cleanName = session.user;
    verifiedTeam = true;
    teamVersion = pushCurrentTeamVersion_(session.user);
  }

  if (!cleanName) {
    return { ok: false, error: 'invalid_name', message: 'Name fehlt.' };
  }

  // Vor der System-Erlaubnis existiert noch keine OneSignal Subscription ID.
  // Die lokale Auswahl darf trotzdem gespeichert bleiben; Backend-Registrierung
  // erfolgt beim zweiten Sync direkt nach optIn().
  if (!cleanSub) {
    return { ok: true, registered: false, waitingForSubscription: true };
  }

  const normalizedPrefs = pushNormalizePrefs_(prefs, cleanRole);
  const sheet = pushSubscriptionsSheet_();
  const row = pushFindSubscriptionRow_(sheet, cleanSub);
  const values = [
    cleanSub,
    cleanName,
    pushNameKey_(cleanName),
    cleanRole,
    verifiedTeam ? '1' : '0',
    teamVersion,
    JSON.stringify(normalizedPrefs),
    active === false ? '0' : '1',
    Date.now()
  ];

  if (row > 1) sheet.getRange(row, 1, 1, values.length).setValues([values]);
  else sheet.appendRow(values);

  return {
    ok: true,
    registered: true,
    name: cleanName,
    role: cleanRole,
    active: active !== false
  };
}

/** Test-Push nur an das aufrufende, bereits registrierte Gerät. */
function serverSendTestPush(subscriptionId, name, teamToken) {
  const cleanSub = String(subscriptionId || '').trim();
  if (!cleanSub) return { ok: false, error: 'no_subscription', message: 'Push ist auf diesem Gerät noch nicht aktiviert.' };

  const row = pushGetSubscriptionById_(cleanSub);
  if (!row) return { ok: false, error: 'not_registered', message: 'Dieses Gerät ist noch nicht registriert.' };

  if (row.role === 'pferdeteam') {
    const session = serverTeamSessionFromToken_(teamToken);
    if (!session || pushNameKey_(session.user) !== row.nameKey || !pushTeamRowStillValid_(row)) {
      return { ok: false, error: 'unauthorized', message: 'Pferdeteam-Zugang bitte neu anmelden.' };
    }
  } else if (pushNameKey_(name) !== row.nameKey) {
    return { ok: false, error: 'identity_mismatch', message: 'Gerät und Person passen nicht zusammen.' };
  }

  const result = pushSend_([
    row.subscriptionId
  ], 'Stall Abenteuerhof', 'Test-Push funktioniert 🐴', {
    type: 'test'
  });

  return result.ok
    ? { ok: true, sent: result.sent }
    : { ok: false, error: 'onesignal', message: result.message || 'OneSignal konnte den Test nicht senden.' };
}

/**
 * Sofort-Push nach neuem Gesundheitseintrag bzw. neuem Hinweis.
 * Gesundheit verlangt ein gültiges Pferdeteam-Token; Infos sind im bestehenden
 * App-Modell für alle Rollen beschreibbar/sichtbar.
 */
function serverPushNewEntry(key, teamToken) {
  key = String(key || '').trim();
  if (!key) return { ok: false, error: 'invalid_key' };

  const isHealth = key.indexOf('gesundheit:') === 0;
  const isInfo = key.indexOf('info:') === 0;
  if (!isHealth && !isInfo) return { ok: false, error: 'unsupported_key' };

  const dedupeKey = 'new:' + key;
  if (pushWasSent_(dedupeKey)) return { ok: true, duplicate: true };

  const data = pushReadAllMainData_();
  const raw = data[key];
  if (!raw) return { ok: false, error: 'not_found' };

  let entry;
  try { entry = JSON.parse(raw); }
  catch (e) { return { ok: false, error: 'invalid_data' }; }

  const created = Number(entry && entry.created || 0);
  if (!created || Math.abs(Date.now() - created) > 15 * 60 * 1000) {
    return { ok: true, ignored: 'not_recent' };
  }

  if (entry.updated) return { ok: true, ignored: 'update' };
  if (entry.notifyOthers === false) return { ok: true, ignored: 'notifications_disabled' };

  let category;
  let title;
  let body;
  let recipientOptions = {};

  if (isHealth) {
    const role = String(entry.rolle || '');

    if (role === 'Pferdeteam') {
      const session = serverTeamSessionFromToken_(teamToken);
      if (!session) return { ok: false, error: 'unauthorized' };

      if (entry.author && pushNameKey_(entry.author) !== pushNameKey_(session.user)) {
        return { ok: false, error: 'author_mismatch' };
      }

      // Pferdeteam-Eintrag: an alle mit Gesundheits-Push, außer der eintragenden Person.
      recipientOptions = {
        teamOnly: false,
        excludeNames: entry.author ? [entry.author] : []
      };
    } else if (role === 'Ehrenamt') {
      // Ehrenamt hat bewusst keinen Pferdeteam-Token.
      // Neue Beobachtungen werden ausschließlich an weiterhin gültige
      // Pferdeteam-Subscriptions gepusht.
      if (!String(entry.author || '').trim()) {
        return { ok: true, ignored: 'missing_author' };
      }

      recipientOptions = {
        teamOnly: true
      };
    } else {
      return { ok: true, ignored: 'unknown_health_role' };
    }

    category = 'health';
    title = role === 'Ehrenamt'
      ? 'Neue Gesundheitsbeobachtung'
      : 'Neuer Gesundheitseintrag';
    body = role === 'Ehrenamt'
      ? 'Aus dem Ehrenamt gibt es einen neuen Gesundheitshinweis in der Stall-App.'
      : 'In der Stall-App gibt es einen neuen Gesundheitshinweis.';
  } else {
    category = 'infos';
    title = 'Neue allgemeine Info';
    body = 'In der Stall-App gibt es einen neuen Hinweis.';
    recipientOptions = {
      teamOnly: false,
      excludeNames: entry.author ? [entry.author] : []
    };
  }

  const recipients = pushRecipients_(category, recipientOptions);
  const result = pushSend_(recipients, title, body, {
    type: category,
    key: key,
    sourceRole: String(entry.rolle || '')
  });

  if (result.ok) pushMarkSent_(dedupeKey);
  return result;
}

/** Einmal von einer Admin-Person aufrufen; erzeugt genau einen 30-Minuten-Trigger. */
function serverEnsurePushTriggers(teamToken) {
  const session = serverRequireAdmin_(teamToken);

  ScriptApp.getProjectTriggers().forEach(function(trigger) {
    if (trigger.getHandlerFunction && trigger.getHandlerFunction() === STALL_PUSH_TRIGGER_FN_) {
      ScriptApp.deleteTrigger(trigger);
    }
  });

  ScriptApp.newTrigger(STALL_PUSH_TRIGGER_FN_)
    .timeBased()
    .everyMinutes(30)
    .create();

  return { ok: true, created: true, by: session.user };
}

/** Zeitgesteuerter Sammelcheck: To-dos, Ponygruppen, Stalldienste. */
function pushScheduledChecks() {
  const cfg = serverPushConfig();
  if (!cfg.enabled) return { ok: false, disabled: true };

  const now = new Date();
  const tz = pushTimezone_();
  const data = pushReadAllMainData_();

  pushCheckTodos_(data, now, tz);
  pushCheckResponsibilities_(data, now, tz);
  pushPruneSent_();

  return { ok: true };
}

/* -------------------------------------------------------------------------- */
/* Scheduled reminder checks                                                   */
/* -------------------------------------------------------------------------- */

function pushCheckTodos_(data, now, tz) {
  const today = Utilities.formatDate(now, tz, 'yyyy-MM-dd');
  const nowMinutes = pushLocalMinutes_(now, tz);
  if (nowMinutes < 8 * 60) return;

  Object.keys(data || {}).forEach(function(key) {
    if (key.indexOf('todo:') !== 0) return;

    let todo;
    try { todo = JSON.parse(data[key]); } catch (e) { return; }
    if (!todo || todo.done) return;
    if (todo.notifyOthers === false) return;
    if (String(todo.repeat || 'once') !== 'once') return;

    const due = String(todo.dueDate || '');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(due)) return;

    let kind = '';
    let title = '';
    let dedupe = '';
    if (due === today) {
      kind = 'due';
      title = 'To-do heute fällig';
      dedupe = 'todo:due:' + String(todo.id || key) + ':' + due;
    } else if (due < today) {
      kind = 'overdue';
      title = 'To-do überfällig';
      dedupe = 'todo:overdue:' + String(todo.id || key) + ':' + due;
    } else {
      return;
    }

    if (pushWasSent_(dedupe)) return;

    const targetNames = pushTodoTargetNames_(todo.assignee);
    const recipients = pushRecipients_('todos', {
      teamOnly: true,
      names: targetNames
    });

    const neutralBody = kind === 'due'
      ? 'In der Stall-App ist eine Aufgabe für heute fällig.'
      : 'Eine Aufgabe in der Stall-App ist noch offen.';
    const result = pushSend_(recipients, title, neutralBody, {
      type: 'todo',
      state: kind,
      todoId: String(todo.id || '')
    });
    if (result.ok) pushMarkSent_(dedupe);
  });
}


function pushDateDiffDays_(fromDateStr, toDateStr) {
  const from = new Date(String(fromDateStr) + 'T12:00:00');
  const to = new Date(String(toDateStr) + 'T12:00:00');
  if (isNaN(from.getTime()) || isNaN(to.getTime())) return 0;
  return Math.round((to.getTime() - from.getTime()) / (24 * 60 * 60 * 1000));
}

function pushCheckResponsibilities_(data, now, tz) {
  const today = Utilities.formatDate(now, tz, 'yyyy-MM-dd');
  const nowMinutes = pushLocalMinutes_(now, tz);
  if (nowMinutes < 8 * 60) return;

  Object.keys(data || {}).forEach(function(key) {
    if (key.indexOf('responsibility:') !== 0) return;

    let item;
    try { item = JSON.parse(data[key]); } catch(e) { return; }
    if (!item || item._archived || item.active === false || item.notifyOthers === false) return;

    const due = String(item.nextDue || '');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(due) || due > today) return;

    const daysOverdue = Math.max(0, pushDateDiffDays_(due, today));
    // Fälligkeitstag sofort; danach nur einmal pro voller Woche überfällig.
    if (daysOverdue > 0 && daysOverdue % 7 !== 0) return;

    const targetNames = pushTodoTargetNames_(item.assignee);
    const recipients = pushRecipients_('checks', {
      teamOnly: false,
      names: targetNames
    });

    const cycle = daysOverdue === 0 ? 'due' : 'overdue-' + String(Math.floor(daysOverdue / 7));
    const dedupe = 'responsibility:' + String(item.id || key) + ':' + due + ':' + cycle;
    if (pushWasSent_(dedupe)) return;

    const title = daysOverdue === 0 ? 'Check heute fällig' : 'Check noch offen';
    const body = 'In der Stall-App ist eine regelmäßige Verantwortung zum Prüfen fällig.';
    const result = pushSend_(recipients, title, body, {
      type: 'responsibility',
      responsibilityId: String(item.id || ''),
      due: due
    });
    if (result.ok) pushMarkSent_(dedupe);
  });
}

function pushCheckPonyGroups_(data, now, tz) {
  const today = Utilities.formatDate(now, tz, 'yyyy-MM-dd');
  const todayWeekday = pushWeekdayForDate_(today);
  const nowMinutes = pushLocalMinutes_(now, tz);

  STALL_PUSH_GROUPS_.forEach(function(group) {
    if (!pushGroupOccursToday_(data, group, today, todayWeekday)) return;

    const startMinutes = pushTimeToMinutes_(group.start);
    const diff = startMinutes - nowMinutes;
    // 30-Minuten-Trigger: dieses Fenster trifft zuverlässig einen Durchlauf
    // ungefähr eine Stunde vor Beginn, ohne doppelte Pushs.
    if (diff < 45 || diff > 75) return;

    const dedupe = 'ponygroup:' + group.id + ':' + today;
    if (pushWasSent_(dedupe)) return;

    const recipients = pushRecipients_('ponygroups', { teamOnly: true });
    const body = group.day + ' · ' + group.title + ' · ' + group.start + ' Uhr';
    const result = pushSend_(recipients, 'Ponygruppe in etwa 1 Stunde', body, {
      type: 'ponygroup',
      groupId: group.id,
      date: today
    });
    if (result.ok) pushMarkSent_(dedupe);
  });
}

function pushCheckShifts_(data, now, tz) {
  const nowMinutes = pushLocalMinutes_(now, tz);
  if (nowMinutes < 18 * 60 + 30) return; // Vorabend, ca. ab 18:30/19 Uhr

  const today = Utilities.formatDate(now, tz, 'yyyy-MM-dd');
  const tomorrow = pushAddDays_(today, 1);
  const byPerson = {};

  Object.keys(data || {}).forEach(function(key) {
    if (key.indexOf('schicht:') !== 0) return;

    let shift;
    try { shift = JSON.parse(data[key]); } catch (e) { return; }
    if (!shift || String(shift.date || '') !== tomorrow) return;

    const names = Array.isArray(shift.names) ? shift.names : [];
    names.forEach(function(name) {
      const clean = String(name || '').trim();
      if (!clean) return;
      const nameKey = pushNameKey_(clean);
      if (!byPerson[nameKey]) byPerson[nameKey] = { name: clean, parts: [] };
      const zeit = String(shift.zeit || '') === 'abends' ? 'Abends' : 'Morgens';
      const art = String(shift.art || '') === 'kann' ? 'Kann' : 'Muss';
      byPerson[nameKey].parts.push(zeit + ' (' + art + ')');
    });
  });

  Object.keys(byPerson).forEach(function(nameKey) {
    const person = byPerson[nameKey];
    const dedupe = 'shift:' + tomorrow + ':' + nameKey;
    if (pushWasSent_(dedupe)) return;

    const recipients = pushRecipients_('shifts', {
      teamOnly: false,
      names: [person.name]
    });
    const body = 'Du bist morgen eingetragen: ' + person.parts.join(' · ');
    const result = pushSend_(recipients, 'Stalldienst morgen', body, {
      type: 'shift',
      date: tomorrow
    });
    if (result.ok) pushMarkSent_(dedupe);
  });
}

/* -------------------------------------------------------------------------- */
/* Audience / registry                                                         */
/* -------------------------------------------------------------------------- */

function pushNormalizePrefs_(prefs, role) {
  prefs = prefs && typeof prefs === 'object' ? prefs : {};
  const isTeam = role === 'pferdeteam';
  return {
    health: prefs.health !== false,
    infos: prefs.infos !== false,
    checks: prefs.checks !== false,
    todos: isTeam && prefs.todos !== false
  };
}

function pushRecipients_(category, options) {
  options = options || {};
  const wantedNames = Array.isArray(options.names) && options.names.length
    ? options.names.map(pushNameKey_).filter(Boolean)
    : null;
  const excludedNames = Array.isArray(options.excludeNames) && options.excludeNames.length
    ? options.excludeNames.map(pushNameKey_).filter(Boolean)
    : [];

  const seen = {};
  const out = [];
  pushAllSubscriptions_().forEach(function(row) {
    if (!row.active || !row.subscriptionId) return;
    if (!row.prefs || row.prefs[category] !== true) return;
    if (options.teamOnly && !pushTeamRowStillValid_(row)) return;
    if (wantedNames && wantedNames.indexOf(row.nameKey) === -1) return;
    if (excludedNames.indexOf(row.nameKey) !== -1) return;
    if (seen[row.subscriptionId]) return;
    seen[row.subscriptionId] = true;
    out.push(row.subscriptionId);
  });
  return out;
}

function pushTeamRowStillValid_(row) {
  if (!row || row.role !== 'pferdeteam' || !row.verifiedTeam || !row.teamVersion) return false;
  try {
    const current = pushCurrentTeamVersion_(row.name);
    return !!current && current === row.teamVersion;
  } catch (e) {
    return false;
  }
}

function pushCurrentTeamVersion_(name) {
  const users = serverTeamUsers_();
  const canonical = serverCanonicalTeamUser_(name, users);
  if (!canonical) return '';
  const admins = serverTeamAdmins_();
  const isAdmin = serverIsAdminName_(canonical, users, admins);
  return serverUserVersion_(canonical, users[canonical], isAdmin, serverAuthSecret_());
}

function pushTodoTargetNames_(assignee) {
  const clean = String(assignee || '').trim();
  if (!clean || clean.toLowerCase() === 'alle') return null;
  return clean
    .split(/\s*(?:,|&|\+|\/|\bund\b)\s*/i)
    .map(function(name) { return name.trim(); })
    .filter(Boolean);
}

function pushSubscriptionsSheet_() {
  const ss = getSheet().getParent();
  let sheet = ss.getSheetByName(STALL_PUSH_SUBS_SHEET_);
  if (!sheet) {
    sheet = ss.insertSheet(STALL_PUSH_SUBS_SHEET_);
    sheet.getRange(1, 1, 1, 9).setValues([[
      'subscription_id', 'name', 'name_key', 'role', 'verified_team',
      'team_version', 'prefs_json', 'active', 'updated_at'
    ]]);
    try { sheet.hideSheet(); } catch (e) {}
  }
  return sheet;
}

function pushSentSheet_() {
  const ss = getSheet().getParent();
  let sheet = ss.getSheetByName(STALL_PUSH_SENT_SHEET_);
  if (!sheet) {
    sheet = ss.insertSheet(STALL_PUSH_SENT_SHEET_);
    sheet.getRange(1, 1, 1, 2).setValues([['dedupe_key', 'sent_at']]);
    try { sheet.hideSheet(); } catch (e) {}
  }
  return sheet;
}

function pushFindSubscriptionRow_(sheet, subscriptionId) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return -1;
  const ids = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0] || '') === subscriptionId) return i + 2;
  }
  return -1;
}

function pushGetSubscriptionById_(subscriptionId) {
  const rows = pushAllSubscriptions_();
  for (let i = 0; i < rows.length; i++) {
    if (rows[i].subscriptionId === subscriptionId) return rows[i];
  }
  return null;
}

function pushAllSubscriptions_() {
  const sheet = pushSubscriptionsSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];

  return sheet.getRange(2, 1, lastRow - 1, 9).getValues().map(function(row) {
    let prefs = {};
    try { prefs = JSON.parse(String(row[6] || '{}')); } catch (e) {}
    return {
      subscriptionId: String(row[0] || '').trim(),
      name: String(row[1] || '').trim(),
      nameKey: String(row[2] || '').trim(),
      role: String(row[3] || '') === 'pferdeteam' ? 'pferdeteam' : 'ehrenamt',
      verifiedTeam: String(row[4] || '') === '1',
      teamVersion: String(row[5] || ''),
      prefs: prefs,
      active: String(row[7] || '') !== '0',
      updatedAt: Number(row[8] || 0)
    };
  }).filter(function(row) { return !!row.subscriptionId; });
}

/* -------------------------------------------------------------------------- */
/* OneSignal                                                                   */
/* -------------------------------------------------------------------------- */

function pushSend_(subscriptionIds, title, body, data) {
  const unique = [];
  const seen = {};
  (subscriptionIds || []).forEach(function(id) {
    id = String(id || '').trim();
    if (!id || seen[id]) return;
    seen[id] = true;
    unique.push(id);
  });

  if (!unique.length) return { ok: true, sent: 0, noRecipients: true };

  const props = PropertiesService.getScriptProperties();
  const appId = String(props.getProperty('ONESIGNAL_APP_ID') || '').trim();
  const apiKey = String(props.getProperty('ONESIGNAL_APP_API_KEY') || '').trim();
  if (!appId || !apiKey) return { ok: false, message: 'OneSignal ist noch nicht konfiguriert.' };

  let sent = 0;
  const chunkSize = 2000;
  for (let i = 0; i < unique.length; i += chunkSize) {
    const chunk = unique.slice(i, i + chunkSize);
    const payload = {
      app_id: appId,
      target_channel: 'push',
      include_subscription_ids: chunk,
      headings: { en: String(title || 'Stall Abenteuerhof'), de: String(title || 'Stall Abenteuerhof') },
      contents: { en: String(body || ''), de: String(body || '') },
      url: pushAppUrl_(),
      chrome_web_icon: pushAppUrl_().replace(/\/$/, '') + '/icon-192.png',
      data: data || {}
    };

    const response = UrlFetchApp.fetch('https://api.onesignal.com/notifications', {
      method: 'post',
      contentType: 'application/json',
      headers: {
        Authorization: 'Key ' + apiKey,
        Accept: 'application/json'
      },
      payload: JSON.stringify(payload),
      muteHttpExceptions: true
    });

    const code = response.getResponseCode();
    const text = response.getContentText();
    if (code < 200 || code >= 300) {
      return { ok: false, sent: sent, message: 'OneSignal HTTP ' + code + ': ' + pushTruncate_(text, 300) };
    }
    sent += chunk.length;
  }

  return { ok: true, sent: sent };
}

/* -------------------------------------------------------------------------- */
/* Main data / dedupe / utilities                                              */
/* -------------------------------------------------------------------------- */

function pushReadAllMainData_() {
  const sheet = getSheet();
  const data = sheet.getDataRange().getValues();
  const out = {};
  for (let i = 1; i < data.length; i++) {
    const key = String(data[i][0] || '');
    if (key) out[key] = data[i][1];
  }
  return out;
}

function pushWasSent_(key) {
  key = String(key || '');
  if (!key) return false;
  const sheet = pushSentSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return false;
  const values = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0] || '') === key) return true;
  }
  return false;
}

function pushMarkSent_(key) {
  if (!key || pushWasSent_(key)) return;
  pushSentSheet_().appendRow([String(key), Date.now()]);
}

function pushPruneSent_() {
  const sheet = pushSentSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return;
  const rows = sheet.getRange(2, 1, lastRow - 1, 2).getValues();
  const cutoff = Date.now() - 180 * 24 * 60 * 60 * 1000;
  const keep = rows.filter(function(row) { return Number(row[1] || 0) >= cutoff; });
  if (keep.length === rows.length) return;
  sheet.getRange(2, 1, lastRow - 1, 2).clearContent();
  if (keep.length) sheet.getRange(2, 1, keep.length, 2).setValues(keep);
}

function pushPonyName_(data, ponyId) {
  try {
    const ponies = JSON.parse(String(data.ponies || '[]'));
    if (!Array.isArray(ponies)) return '';
    const found = ponies.find(function(p) { return String(p && p.id || '') === String(ponyId || ''); });
    return found ? String(found.name || '') : '';
  } catch (e) {
    return '';
  }
}

function pushGroupOccursToday_(data, group, today, todayWeekday) {
  let occurs = false;
  const todayScheduleKey = 'ponygroup:schedule:' + group.id + ':' + today;
  const todaySchedule = pushParseJson_(data[todayScheduleKey]);

  if (group.weekday === todayWeekday) {
    if (!todaySchedule) {
      occurs = true;
    } else if (!todaySchedule.cancelled && String(todaySchedule.date || today) === today) {
      occurs = true;
    }
  }

  // Ein anderer regulärer Slot kann auf heute verschoben worden sein.
  const prefix = 'ponygroup:schedule:' + group.id + ':';
  Object.keys(data || {}).forEach(function(key) {
    if (occurs && key === todayScheduleKey) return;
    if (key.indexOf(prefix) !== 0 || key === todayScheduleKey) return;
    const schedule = pushParseJson_(data[key]);
    if (schedule && !schedule.cancelled && String(schedule.date || '') === today) occurs = true;
  });

  return occurs;
}

function pushParseJson_(raw) {
  if (!raw) return null;
  try { return JSON.parse(raw); } catch (e) { return null; }
}

function pushNameKey_(name) {
  return String(name || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
}

function pushTruncate_(value, max) {
  const text = String(value || '').replace(/\s+/g, ' ').trim();
  if (text.length <= max) return text;
  return text.slice(0, Math.max(1, max - 1)).trim() + '…';
}

function pushTimezone_() {
  return String(PropertiesService.getScriptProperties().getProperty('STALL_TIMEZONE') || STALL_PUSH_DEFAULT_TZ_).trim() || STALL_PUSH_DEFAULT_TZ_;
}

function pushAppUrl_() {
  let url = String(PropertiesService.getScriptProperties().getProperty('STALL_APP_URL') || STALL_PUSH_DEFAULT_URL_).trim();
  if (!url) url = STALL_PUSH_DEFAULT_URL_;
  return /\/$/.test(url) ? url : url + '/';
}

function pushLocalMinutes_(date, tz) {
  const hhmm = Utilities.formatDate(date, tz, 'HH:mm').split(':');
  return Number(hhmm[0] || 0) * 60 + Number(hhmm[1] || 0);
}

function pushTimeToMinutes_(hhmm) {
  const parts = String(hhmm || '').split(':');
  return Number(parts[0] || 0) * 60 + Number(parts[1] || 0);
}

function pushWeekdayForDate_(yyyyMmDd) {
  const d = new Date(String(yyyyMmDd) + 'T00:00:00Z');
  const day = d.getUTCDay();
  return day === 0 ? 7 : day;
}

function pushAddDays_(yyyyMmDd, days) {
  const d = new Date(String(yyyyMmDd) + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + Number(days || 0));
  return Utilities.formatDate(d, 'UTC', 'yyyy-MM-dd');
}
